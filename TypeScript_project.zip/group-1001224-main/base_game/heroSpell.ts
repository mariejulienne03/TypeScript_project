import Message from "./getAllMessages";
import Characters from "./Interfaces/InterfaceCharacters";

// Function heal Hero
export function heroHeal(Hero: Characters, VieMaxHero: number): void {
  const halfLife = (VieMaxHero / 2);
  Hero.hp = Hero.hp > halfLife ? VieMaxHero : Hero.hp + halfLife;
  Message.getHeal();
}

// Function calc hero damage to monster
export function heroAttack(atkHero: number, Monster: Characters): void {
  Monster.hp = (atkHero > Monster.hp) ? 0 : (Monster.hp - atkHero);
  Message.getHeroAttack(atkHero, Monster);
}
