import Message from './getAllMessages';
import Characters from './Interfaces/InterfaceCharacters';

export default function MonsterAttacks(
  Hero: Characters,
  Monster: Characters,
  isProtect: boolean,
): void {
  Hero.hp -= isProtect ? (Monster.str / 2) : (Monster.str);
  if (isProtect) Message.getProtect();
  Message.getEnnemyAttack(Monster);
  Message.breakLine();
}
