import Level from './Interfaces/IntefaceLevel';
import Message from './Interfaces/IntefaceMessage';
import Characters from './Interfaces/InterfaceCharacters';

const getIntro = (heroName: string, bossName: string) => {
  console.log(`               
                                                                                                  T~~
                                                                                                  |
                                                                                                  /"\\\\
                                                                                          T~~     |'| T~~
                                                                                      T~~ |    T~ WWWW|
                                                                                      |  /"\\\   |  |  |/\\T~~
                                                                                    /"\\ WWW  /"\\ |' |WW|
                                                                                    WWWWW/\\| /   \\|'/\\|/"\\
                                                                                    |   /__\\/]WWW[\\/__\\WWWW
                                                                                    |"  WWWW'|I_I|'WWWW'  |
                                                                                    |   |' |/  -  \\|' |'  |
                                                                                    |'  |  |LI=H=LI|' |   |
                                                                                    |   |' | |[_]| |  |'  |
                                                                                    |   |  |_|###|_|  |   |
                                                                                    '---'--'-/___\\-'--'---'
                        A very long time ago the planet ETNA lived peacefully, all the villages of the planet were preparing the wedding ceremony of \x1b[33m${heroName}\x1b[0m,
                        our hero and the Princess of the planet ETNA... when suddenly the horrible monster \x1b[35m${bossName}\x1b[0m and his horde of assets invaded the planet but also kidnap the princess Linda… 
                        Lien must absolutely defeat his demons!\n\n`);
};

const getFloor = (nbrFloor: number) => {
  console.log(`\n\n${'\t'.repeat(8)}${'\uD83E\uDDF1'.repeat(10)} FIGHT ${nbrFloor} ${'\uD83E\uDDF1'.repeat(10)}`);
};
const getBossDefeat = (monsterName: string, heroName: string) => {
  console.log(`${'\t'.repeat(8)}Congratulation \x1b[33m${heroName}\x1b[0m, you defeat \x1b[35m${monsterName}\x1b[0m and win The game !\n\n`);
};
const getTheEnd = (heroName: string) => {
  console.log(`
                                                   _      _
                                                  ( \\---/ )
                                                    ) . . (
                      ________________________,--._(___Y___)_,--._______________________
                                              \`--'           \`--'
      
                CHEER \x1b[33m${heroName}\x1b[0m! you have freed the princess Linda, now that you have eliminated all her assets monster, life on the planet ETNA can resume its course ;)
      \n\n`);
};
const getInterface = (
  monster: Characters,
  hero: Characters,
  hpMaxMonster: number,
  hpMaxHero: number,
  heroLevel: Level,
) => `
  \x1b[35m${monster.name}\x1b[0m Lvl: 1
  HP : ${'\x1b[31m\uD83E\uDD0E\x1b[0m'.repeat(monster.hp)}${'\uD83D\uDC94'.repeat(hpMaxMonster - monster.hp)} ${monster.hp} / ${hpMaxMonster} hp

  \x1b[33m${hero.name}\x1b[0m Lvl: ${heroLevel.level}
  HP: ${'\x1b[32m\uD83E\uDD0E\x1b[0m'.repeat(hero.hp)}${'\uD83D\uDC94'.repeat(hpMaxHero - hero.hp)} ${hero.hp} / ${hpMaxHero} hp
  Exp: ${'\x1b[36m\uD83D\uDCA0\x1b[0m'.repeat(heroLevel.xp / 2)}${'\x1b[90m\uD83D\uDCA0\x1b[0m'.repeat((heroLevel.containerXp - heroLevel.xp) / 2)} \t ${heroLevel.xp} / ${heroLevel.containerXp} xp

  ${'\t'.repeat(8)}${'\x1b[33m\uD83D\uDCA5\x1b[0m '.repeat(5)}What do you choose hero ? ${'\x1b[33m\uD83D\uDCA5\x1b[0m '.repeat(5)}

  ${'\t'.repeat(8)}\x1b[31m1.\u270A Attack\x1b[0m  ||  \x1b[32m2.\uD83C\uDF31 Heal\x1b[0m  ||  3.\x1b[36m\uD83C\uDF10 Protect\x1b[0m  ||  4.\x1b[2m\uD83D\uDC0C Escape\x1b[0m

  `;
const getPause = (heroName: string, monsterName: string, floor: number) => `${'\t'.repeat(8)}Good job \x1b[33m${heroName}\x1b[0m, you defeat \x1b[35m${monsterName}\x1b[0m at the floor ${floor}

    ${'\t'.repeat(8)} Press any Key to continue ur adventure !!\n
    `;
const breakLine = () => console.log(`\n${'\t'.repeat(6)}${'\x1b[2m\uD83C\uDF80\x1b[0m'.repeat(50)}\n`);

const getMonsterCome = (monsterName: string) => {
  console.log(`
    ${'\t'.repeat(8)}${'\x1b[33m\u26A0\x1b[0m '.repeat(5)} A \x1b[35m${monsterName}\x1b[0m savage appears! ${'\x1b[33m\u26A0\x1b[0m '.repeat(5)}
    `);
};
const getWelcome = () => `                                                                                                           
                                          ::::::'##:::::'##:'########:'##::::::::'######:::'#######::'##::::'##:'########::::'########::'#######::              
                                          :::::: ##:'##: ##: ##.....:: ##:::::::'##... ##:'##.... ##: ###::'###: ##.....:::::... ##..::'##.... ##:              
                                          :::::: ##: ##: ##: ##::::::: ##::::::: ##:::..:: ##:::: ##: ####'####: ##::::::::::::: ##:::: ##:::: ##:              
                                          :::::: ##: ##: ##: ######::: ##::::::: ##::::::: ##:::: ##: ## ### ##: ######::::::::: ##:::: ##:::: ##:              
                                          :::::: ##: ##: ##: ##...:::: ##::::::: ##::::::: ##:::: ##: ##. #: ##: ##...:::::::::: ##:::: ##:::: ##:              
                                          :::::: ##: ##: ##: ##::::::: ##::::::: ##::: ##: ##:::: ##: ##:.:: ##: ##::::::::::::: ##:::: ##:::: ##:              
                                          ::::::. ###. ###:: ########: ########:. ######::. #######:: ##:::: ##: ########::::::: ##::::. #######::              
                                          :::::::...::...:::........::........:::......::::.......:::..:::::..::........::::::::..::::::.......:::              
                                          '########:'########:'##::: ##::::'###:::::::'########::'##::::'##:'##::: ##::'######:::'########::'#######::'##::: ##:
                                          ##.....::... ##..:: ###:: ##:::'## ##:::::: ##.... ##: ##:::: ##: ###:: ##:'##... ##:: ##.....::'##.... ##: ###:: ##:
                                          ##:::::::::: ##:::: ####: ##::'##:. ##::::: ##:::: ##: ##:::: ##: ####: ##: ##:::..::: ##::::::: ##:::: ##: ####: ##:
                                          ######:::::: ##:::: ## ## ##:'##:::. ##:::: ##:::: ##: ##:::: ##: ## ## ##: ##::'####: ######::: ##:::: ##: ## ## ##:
                                          ##...::::::: ##:::: ##. ####: #########:::: ##:::: ##: ##:::: ##: ##. ####: ##::: ##:: ##...:::: ##:::: ##: ##. ####:
                                          ##:::::::::: ##:::: ##:. ###: ##.... ##:::: ##:::: ##: ##:::: ##: ##:. ###: ##::: ##:: ##::::::: ##:::: ##: ##:. ###:
                                          ########:::: ##:::: ##::. ##: ##:::: ##:::: ########::. #######:: ##::. ##:. ######::: ########:. #######:: ##::. ##:
                                          ........:::::..:::::..::::..::..:::::..:::::........::::.......:::..::::..:::......::::........:::.......:::..::::..::
`;
const getMalek = (name: string, nbrFight: number) => console.log(`${'\t'.repeat(4)}The ${name.toUpperCase()} (rattus Gigantus) is very agile and fast, as it has to go through the ETNA sewers. Its jaws are powerful to eat the same things as the heroes.\n${'\t'.repeat(4)} They are organized in colonies, very hierarchical. On their territory, they only move to steal \uD83C\uDF5F fries or cigarette, to which the dominant ones have a priority access.\n
${'\t'.repeat(4)}You escaped from the Matrix, you stole all the monsters from the dungeon and even Princess Linda.
${'\t'.repeat(4)}You collected ${nbrFight}  packs of \uD83D\uDEAC and ${nbrFight}  \uD83C\uDF5F.\n
${'\t'.repeat(8)}Thanks for playing my little rats!
`);
const getStart = () => `${'\t'.repeat(10)}1. Start || 2. Rage Quit\n\n`;
const getQuit = () => console.log(`
                                     _      ________  _ _____    _____  _  _      _____   _      ____  ____  ____ 
                                    / \\  /|/  __/\\  \\///__ __\\  /__ __\\/ \\/ \\__/|/  __/  / \\  /|/  _ \\/  _ \\/  __\\
                                    | |\\ |||  \\   \\  /   / \\      / \\  | || |\\/|||  \\    | |\\ ||| / \\|| / \\|| | //
                                    | | \\|||  /_  /  \\   | |      | |  | || |  |||  /_   | | \\||| \\_/|| \\_/|| |_\\\\
                                    \\_/  \\|\\____\\/__/\\\\  \\_/      \\_/  \\_/\\_/  \\|\\____\\  \\_/  \\|\\____/\\____/\\____/
    `);
const getElie = () => console.log(`
                                      ____    __    ______  ____        __      ____                 ____    ______  __      __      ____    __  __  ____       
                                    /\\  _\`\\ /\\ \\  /\\__  _\\/\\  _\`\\     /\\ \\    /\\  _\`\\       /'\\_/\`\\/\\  _\`\\ /\\__  _\\/\\ \\    /\\ \\    /\\  _\`\\ /\\ \\/\\ \\/\\  _\`\\     
                                    \\ \\ \\L\\_\\ \\ \\ \\/_/\\ \\/\\ \\ \\L\\_\\   \\ \\ \\   \\ \\ \\L\\_\\    /\\      \\ \\ \\L\\_\\/_/\\ \\/\\ \\ \\   \\ \\ \\   \\ \\ \\L\\_\\ \\ \\ \\ \\ \\ \\L\\ \\   
                                     \\ \\  _\\L\\ \\ \\  _\\ \\ \\ \\ \\  _\\L    \\ \\ \\  _\\ \\  _\\L    \\ \\ \\__\\ \\ \\  _\\L  \\ \\ \\ \\ \\ \\  _\\ \\ \\  _\\ \\  _\\L\\ \\ \\ \\ \\ \\ ,  /   
                                      \\ \\ \\L\\ \\ \\ \\L\\ \\_\\ \\_\\ \\ \\L\\ \\   \\ \\ \\L\\ \\ \\ \\L\\ \\   \\ \\ \\_/\\ \\ \\ \\L\\ \\ \\_\\ \\_\\ \\ \\L\\ \\ \\ \\L\\ \\ \\ \\L\\ \\ \\ \\_\\ \\ \\ \\\\ \\  
                                       \\ \\____/\\ \\____/\\_____\\ \\____/    \\ \\____/\\ \\____/    \\ \\_\\\\ \\_\\ \\____/ /\\_____\\ \\____/\\ \\____/\\ \\____/\\ \\_____\\ \\_\\ \\_\\
                                        \\/___/  \\/___/\\/_____/\\/___/      \\/___/  \\/___/      \\/_/ \\/_/\\/___/  \\/_____/\\/___/  \\/___/  \\/___/  \\/_____/\\/_/\\/ /
                                                                                                                                                              `);
const getDifficulty = () => `
    ${'\t'.repeat(10)}Choose difficulty Player\n
    ${'\t'.repeat(8)}1.\x1b[45m \uD83D\uDC00 Malek (Easy) \x1b[0m || 2.\x1b[32m\uD83D\uDC10 Yassine (Difficult)\x1b[0m || 3.\x1b[31m\uD83D\uDC09 Elie (Insane)\x1b[0m 
    `;
const chooseDifficulty = (name: string) => {
  if (name === 'elie') console.log(`${'\t'.repeat(8)}\x1b[45m Dude ur choosing ${name} difficulty! Good Death, he is INSANE \x1b[0m\n\n`);
  else console.log(`${'\t'.repeat(8)}Nice player ur choosing ${name} difficulty! Good Luck\n\n`);
};
const chooseNbrFloor = () => `${'\t'.repeat(10)}Choose number of fight\n
    ${'\t'.repeat(9)} 1. 10  ||  2. 20  ||  3. 50  ||  4. 100\n
    `;
const chooseCharacter = () => `${'\t'.repeat(8)}1. Create your character  ||  2. Use a random character\n`;
const getCoins = (coin: number) => {
  console.log(`${'\t'.repeat(11)}You gain \x1b[33m1\x1b[0m more coin!
    ${'\t'.repeat(10)}Now you have \x1b[33m${coin}\x1b[0m coins in ur inventory
    `);
};
const getEscapeLuck = (monster: Characters, nbrInsane: number) => {
  console.log(`${'\t'.repeat(6)}Used \x1b[2mEscape\x1b[0m, you are lucky and loose ${nbrInsane} HP by ${monster.name} and skip this floor. You hear in the distance ${monster.name} laughing at you and howling cowardly\n`);
};
const getEscapeUnlucky = (monster: Characters, nbrInsane: number) => {
  console.log(`${'\t'.repeat(6)}Used \x1b[2mEscape\x1b[0m, you are unlucky and loose ${nbrInsane} HP by ${monster.name}. You hear in the distance ${monster.name} laughing at you and howling cowardly\n`);
};
const getProtect = () => {
  console.log(`${'\t'.repeat(8)}Used \x1b[36mProtect\x1b[0m !\n`);
};
const getDieHero = () => {
  console.log(`
                                                      ---   .    ____        -----      ______   -----        .
                                                  ___     / \\             .....................      ____   / \\
                                                        .'   '.  --  ..:::::''''''''''''''''':::::..      .'   '.
                                                  ---   | ^ ^ |    .::::''''          (_     ''''::::. -- | ^ ^ '
                                                        | ^ ^ |  .::''                       _)    ''::.  | ^ ^ | --
                                                ____     '...'  .::'              .-.      (_        '::.  '...'
                                                        .-.!_  .::'       _)     /   \\                '::.   ! ____
                                                      / / \`-\`.:'                '-.-'            _)    ':..""".
                                                --    ' |  '.|:'      _)         .'.       (_          ':/' |  \\
                                                      | |   |'.               _/^---^\\_                  |     . --
                                                ___    \\ .  '|               \\-------../         (_      \\   '.'
                                                        ' :   '        _)      '.\\:::/.'       (_   )_    |'   || ___
                                                        | |  .|      _(         | | |'|                   / ' . |
                                                    --  | '. | \\                '.\\ /.'                   '.  | |--
                                                        |'.   '|                 |[ ]|           (_       | .'  |____
                                                __    .'\\ |  .'\\                 '.^.'                    \\ |.  .
                                                    .'-.\\'. | |        _)        (:)                     | ||| |
                                                  .'    \\'..' .             _..--'''--.._      (_       /'-._.-'| ---
                                                  |       \`-..'.         .-'             '-.           |      .-'.
                                                    \\            \`-.    .'  ..            .. '.        .'-._.-'    \`.
                                                --   )              \`-./    '::.        .::'   \\   _.-'             /
                                                    '._/-..          /       '::.    .::'      \\-'              .-'
                                                        ::.\`-.      ''        '::   ::'        ''       _..-\\_.'
                                                        :::   '._   | \\         '   '         / |    .-'   .:: _____
                                                ____     :::      \`-.|  '  .----..___..----.  '  | .-'      :::
                                                        :::          \\ |  _..--.     .--.._  | /-'         ::: ---
                                                        :::   _)     | ' /     |     |     \\ ' |  (        :::
                                                  --    :::          )   |   _.'     '._   |   (   )_      :::____
                                                    ____ :::          /'. \\_.'   )\\ /(   '._/ .'\\     (_    :::
                                                        :::       .-'|  \`-->-@ /     \\ @->--'  |-.         :::
                                                        :::    .-'   \\         | / \\ |         /  \`-.      :::  ---
                                                ----    '' _.-'       |        )/   \\(        |      \`-.   :::  _____
                                                  _.-=--..-'          . \\ /\\               /\\ /          \`-. ''
                                                /.._    \`.        .-'   .\\ '-.\\.\\\\.//./.-' /.\`-.           \`---.._
                                                |    \`.    \\    .-'      | '.             .' |   \`-.                \\ 
                                                \\    _\\.   \`.-'         |   '-././.\\.\\.-'   |      \`.               |
                                                  \`.-'  |   /::::::::::: \\                   /::::::::\`.      ,-.    /
                                                - |   /   /         ----  '-.             .-'     ----  \`.    |  \\_.'
                                                __ \\   | .'     _____        '-._._._._.-'     ____      |    |   |
                                                    \`--'                                                 \`-.  '._ / --
                                                                                                            \`...-'
                                                                                                            
                                                                        YOU   DIE  \x1b[45m NOOB \x1b[0m\n\n`);
};
const getEnnemyAttack = (monster: Characters) => {
  console.log(`${'\t'.repeat(8)}\x1b[35m${monster.name}\x1b[0m attacked and dealt \x1b[31m${monster.str}\x1b[0m damages
    
  ${'\t'.repeat(8)}You lost \x1b[31m${monster.str}\x1b[0m HP\n`);
};
const getHeroAttack = (atkHero: number, monster: Characters) => {
  console.log(`${'\t'.repeat(8)}You attacked and dealt \x1b[31m${atkHero}\x1b[0m damages!
    
  ${'\t'.repeat(8)}\x1b[35m${monster.name}\x1b[0m have ${monster.hp} HP!\n\n`);
};
const getHeal = () => {
  console.log(`${'\t'.repeat(8)}You used \x1b[32mheal\x1b[0m!\n`);
};
const getLevel = (hero: Characters, level: number, hpMaxHero: number) => {
  console.log(`${'\t'.repeat(10)}Congratulation \x1b[33m${hero.name}\x1b[0m, you gain \x1b[33m1\x1b[0m level.

  ${'\t'.repeat(9)}You are now Level ${level}, ur stats up : life max : \x1b[32m${hpMaxHero} HP\x1b[0m AND Strenght : \x1b[31m${hero.str}\x1b[0m.
  `);
};

const Messages: Message = {
  getWelcome,
  getStart,
  getQuit,
  getElie,
  getDifficulty,
  chooseDifficulty,
  chooseNbrFloor,
  chooseCharacter,
  getIntro,
  getFloor,
  getMonsterCome,
  getInterface,
  getHeroAttack,
  getHeal,
  getProtect,
  getMalek,
  getEscapeLuck,
  getEscapeUnlucky,
  getEnnemyAttack,
  getPause,
  breakLine,
  getBossDefeat,
  getCoins,
  getLevel,
  getDieHero,
  getTheEnd,
};

export default Messages;
