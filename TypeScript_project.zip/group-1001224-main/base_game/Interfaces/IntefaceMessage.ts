import Level from './IntefaceLevel';
import Characters from './InterfaceCharacters';

export default interface Message {
  /** Displays game  banner */
  readonly getWelcome: () => void;
  /** Starts the game  */
  readonly getStart: () => string;
  /** Quit the game */
  readonly getQuit: () => void;
  /** Displays Elie le meilleur if the user types 'elie' */
  readonly getElie: () => void;
  /** Displays Malek the special rats
   * @param name : need name monster
   * @param nbrFight : need number of fight
   */
  getMalek(name: string, nbrFight: number): void;
  /** Displays difficulty levels  */
  readonly getDifficulty: () => string;
  /**
   *
   * @param name : returns a name according to difficulty levels
   */
  chooseDifficulty(name: string): void;
  /** Asks the user number of floor */
  readonly chooseNbrFloor: () => string;
  /** Asks the user if he wants to create a character */
  readonly chooseCharacter: () => string;
  /** Displays a breakLine */
  readonly breakLine: () => void;
  /** Displays the getIntro
   * @param heroName : user's name
   * @param bossName : ennemy's name
   */
  getIntro: (heroName: string, bossName: string) => void;
  /** Displays the number of floors
   * @param : takes number of floors entered by the user
   */
  getFloor(nbrFloor: number): void;
  /**
   *
   * @param monsterName: displays the level's monster's name
   */
  getMonsterCome(monsterName: string): void
  /** Displays the interface of all the characters */
  getInterface(monster: Characters,
    hero: Characters,
    hpMaxMonster: number,
    hpMaxHero: number,
    heroLevel: Level
  ): string;
  /** Displays the Hero attack and the damages done on the monster
   * @param atkHero: strenght / attack of the hero
   * @param monster: interface of the monster
   */
  getHeroAttack(atkHero: number, monster: Characters): void;
  /** Use the ability of the hero to heal itself  */
  readonly getHeal:() => void;
  /** Displays the escape of the hero:
   * @param monster : object of monster
   * @param nbrInsane : number that doesnt multiply the ennemy's ability
   */
  getEscapeLuck(monster: Characters, nbrInsane: number): void;
  /** Displays the escape of the hero:
   * @param monster : object of monster
   * @param nbrInsane : number that multiplies the ennemy's ability
   */
  getEscapeUnlucky(monster: Characters, nbrInsane: number): void;
  /**
   * Hero's ability to divide the ennemy attack by 2
   */
  readonly getProtect: () => void;
  /**
   * Displays the monster's attack
   * @param monster : monster's object
   */
  getEnnemyAttack(monster: Characters): void;
  /**
   * Displays a message that says where and by whom the player was defeated
   * @param heroName : Hero's name
   * @param monsterName : Monster's name
   * @param floor : current level
   */
  getPause(heroName: string, monsterName: string, floor: number): string;
  /**
  *Displays a message that says where and who the user's defeated
  * @param monsterName : name of the monster
  * @param heroName : name of the hero
  */
  getBossDefeat(monsterName: string, heroName: string): void;
  /** Displays the number of coins that the user earned
   * @param coin : number of coins
   */
  getCoins(coin: number): void;
  /** Displays when the user's level improve
   * @param hero : object of the hero
   * @param level : level of the hero
   * @param hpHeroMax : full hp parameter of the hero
   */
  getLevel(hero: Characters, level: number, hpHeroMax: number): void;
  /**  */
  readonly getDieHero: () => void;
  getTheEnd(heroName: string): void;
}
