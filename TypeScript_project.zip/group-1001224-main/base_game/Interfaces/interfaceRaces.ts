export default interface Races {
  id: number,
  name: string,
  strenght : number[] | null,
  weakness : number[] | null,
  rarity: number | null
}
