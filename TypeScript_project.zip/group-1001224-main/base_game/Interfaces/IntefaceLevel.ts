export default interface Level {
  xp: number,
  level: number,
  containerXp: number,
}
