import Characters from '../Interfaces/InterfaceCharacters';

function calcStats(stat: number) {
  return Math.floor(stat * 1.5);
}
export function getDifficult(monsters: Characters[]) {
  return monsters.map((monster) => ({
    ...monster,
    hp: calcStats(monster.hp),
    def: calcStats(monster.def),
    int: calcStats(monster.int),
    luck: calcStats(monster.luck),
    mp: calcStats(monster.mp),
    res: calcStats(monster.res),
    spd: calcStats(monster.spd),
    str: calcStats(monster.str),
  }));
}
export function getInsane(monsters: Characters[]) {
  return monsters.map((monster) => ({
    ...monster,
    hp: monster.hp * 2,
    def: monster.def * 2,
    int: monster.int * 2,
    luck: monster.luck * 2,
    mp: monster.mp * 2,
    res: monster.res * 2,
    spd: monster.spd * 2,
    str: monster.str * 2,
  }));
}
