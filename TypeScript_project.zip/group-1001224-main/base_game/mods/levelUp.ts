import Level from '../Interfaces/IntefaceLevel';
import Messages from '../getAllMessages';
import Characters from '../Interfaces/InterfaceCharacters';

export function getRandomXp(): number {
  return (Math.floor(Math.random() * (51 - 15) + 15));
}
export function levelUp(containerHeroXp : Level, hero: Characters, heroHpMax: number[]) {
  containerHeroXp.level += 1;
  containerHeroXp.xp -= containerHeroXp.containerXp;
  containerHeroXp.containerXp = Math.ceil(containerHeroXp.containerXp * 1.5);
  heroHpMax[0] = Math.ceil(heroHpMax[0] * 1.1);
  hero.str = Math.ceil(hero.str * 1.1);
  Messages.getLevel(hero, containerHeroXp.level, heroHpMax[0]);
}
