import Characters from '../Interfaces/InterfaceCharacters';
import * as Races from '../characters/race.json';
import * as Class from '../characters/class.json';
import createHero from './createHero';
import Messages from '../getAllMessages';

const readlineSync = require('readline-sync');

export default function chooseCharacter(hero: Characters[]): boolean {
  Messages.breakLine();
  const UserChoice: string = readlineSync.question(Messages.chooseCharacter(), (res:string) => res);

  if (UserChoice !== '1') return false;
  hero.unshift(createHero(Races, Class));
  return true;
}
