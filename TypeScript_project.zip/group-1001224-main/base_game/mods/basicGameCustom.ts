import Messages from '../getAllMessages';
import Characters from '../Interfaces/InterfaceCharacters';
import { getDifficult, getInsane } from './difficulty';

const rl = require('readline-sync');

export default function GameStart(
  monsters: Characters[],
  boss: Characters[],
  nbrFight: number[],
): boolean {
  console.log(Messages.getWelcome());
  Messages.breakLine();
  let response: string = rl.question(Messages.getStart(), (res: string) => res);
  if (response === '2') {
    Messages.getQuit();
    return false;
  } if (response === 'elie') {
    Messages.getElie();
    return false;
  }
  Messages.breakLine();
  response = rl.question(Messages.getDifficulty(), (res: string) => res);
  if (response === '1') {
    Messages.chooseDifficulty('Malek');
    Messages.breakLine();
  }
  if (response === '2') {
    Messages.chooseDifficulty('Yassine');
    Messages.breakLine();
    monsters = getDifficult(monsters);
    boss = getDifficult(boss);
  } else if (response === '3') {
    Messages.chooseDifficulty('elie');
    Messages.breakLine();
    monsters = getInsane(monsters);
    boss = getInsane(boss);
  }
  response = rl.question(Messages.chooseNbrFloor(), (res: string) => res);
  if (response === '2') nbrFight[0] = 20;
  if (response === '3') nbrFight[0] = 50;
  if (response === '4') nbrFight[0] = 100;
  return true;
}
