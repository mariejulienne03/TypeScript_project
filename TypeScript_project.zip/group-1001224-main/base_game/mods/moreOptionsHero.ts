import Messages from '../getAllMessages';
import Characters from '../Interfaces/InterfaceCharacters';

export default function getEscape(monster: Characters, hero: Characters): void {
  monster.hp = 0;
  const nbrInsane: number = Math.floor(monster.str / Math.random() + 1);
  hero.hp -= nbrInsane;
  if (hero.hp > 0) Messages.getEscapeLuck(monster, nbrInsane);
  else Messages.getEscapeUnlucky(monster, nbrInsane);
}
