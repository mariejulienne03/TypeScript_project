import Characters from '../Interfaces/InterfaceCharacters';
import Messages from '../getAllMessages';

const readlineSync = require('readline-sync');

export default function createHero(race : any, classes: any) { // function used to customize a Hero
  console.log(`${'\t'.repeat(8)}*-------CREATE YOUR CHARACTER------*\n\n`);
  // questionner l'utilisateur
  let myCreatedHero: Characters; // initialisation of the customized character Object
  let isTrue: boolean = true; // boolean variable used to ask the user's preferences
  let test1: boolean = true; // boolean variable used for validation the user's answers

  const MyCustomHero:Characters = { // creation of the customized hero object
    id: NaN, // setting NaN to later on check if the user entered a number
    hp: NaN,
    mp: NaN,
    str: NaN,
    int: NaN,
    def: NaN,
    res: NaN,
    spd: NaN,
    luck: NaN,
    rarity: NaN,
    name: '',
    class: NaN,
    race: NaN,
  };

  const getRaces: string[] = race.map(//  only takes race names as indexes
    (index: Characters) => index.name,
  );
  const getClasses: string[] = classes.map(// takes class names as indexes
    (index: Characters) => index.name,
  );
  MyCustomHero.name = readlineSync.question(`${'\t'.repeat(9)}Pick a name ➳ `);

  while (isTrue) { // loop to start the questions and restart if the user says no at the end
    while (test1) { // checking if the user enters a valid digit for each parameters
      if (Number.isNaN(Number(MyCustomHero.hp)) === true || MyCustomHero.hp > 100) {
        MyCustomHero.hp = Number(readlineSync.question(`${'\t'.repeat(9)}\x1b[34mHP up to 100 ➳ \x1b[0m`));
      } else test1 = false; // if the user answered a valid digit, we break from the loop
    }
    test1 = true; // reseting test1 as true

    while (test1) {
      if (Number.isNaN(Number(MyCustomHero.mp)) === true || MyCustomHero.mp > 250) {
        MyCustomHero.mp = Number(readlineSync.question(`${'\t'.repeat(9)}\x1b[35mMP up to 250 ➳ \x1b[0m`));
      } else test1 = false;
    }
    test1 = true;

    while (test1) {
      if (Number.isNaN(Number(MyCustomHero.int)) === true || MyCustomHero.int > 20) {
        MyCustomHero.int = Number(readlineSync.question(`${'\t'.repeat(9)}\x1b[31mINT up to 20 ➳ \x1b[0m`));
      } else test1 = false;
    }
    test1 = true;

    while (test1) {
      if (Number.isNaN(Number(MyCustomHero.def)) === true || MyCustomHero.def > 10) {
        MyCustomHero.def = Number(readlineSync.question(`${'\t'.repeat(9)}\x1b[33mDEF up to 10 ➳ \x1b[0m`));
      } else test1 = false;
    }
    test1 = true;

    while (test1) {
      if (Number.isNaN(Number(MyCustomHero.luck)) === true || MyCustomHero.luck > 26) {
        MyCustomHero.luck = Number(readlineSync.question(`${'\t'.repeat(9)}\x1b[32mLUCK up to 26 ➳ \x1b[0m`));
      } else test1 = false;
    }
    test1 = true;

    while (test1) {
      if (Number.isNaN(Number(MyCustomHero.str)) === true || MyCustomHero.str > 16) {
        MyCustomHero.str = Number(readlineSync.question(`${'\t'.repeat(9)}\x1b[31mSTR up to 16 ➳ \x1b[0m`));
      } else test1 = false;
    }
    test1 = true;

    while (test1) {
      if (Number.isNaN(Number(MyCustomHero.res)) === true || MyCustomHero.res > 9) {
        MyCustomHero.res = Number(readlineSync.question(`${'\t'.repeat(9)}\x1b[36mRES up to 9 ➳ \x1b[0m`));
      } else test1 = false;
    }
    test1 = true;

    while (test1) {
      if (Number.isNaN(Number(MyCustomHero.spd)) === true || MyCustomHero.spd > 12) {
        MyCustomHero.spd = Number(readlineSync.question(`${'\t'.repeat(9)}\x1b[34mSPD up to 12 ➳ \x1b[0m`));
      } else test1 = false;
    }
    test1 = true;

    while (test1) {
      if (Number.isNaN(Number(MyCustomHero.rarity)) === true || MyCustomHero.rarity > 5) {
        MyCustomHero.rarity = Number(readlineSync.question(`${'\t'.repeat(9)}\x1b[33mRARITY up to 5 ➳ \x1b[0m`));
      } else test1 = false;
    }
    test1 = true;

    while (test1) {
      if (Number.isNaN(Number(MyCustomHero.race)) === true) {
        MyCustomHero.race = Number(readlineSync.keyInSelect(getRaces, `${'\t'.repeat(9)}\x1b[35mCHARACTER'S RACE ➳ \x1b[0m`));
      } else test1 = false;
    }
    test1 = true;

    while (test1) {
      if (Number.isNaN(Number(MyCustomHero.class)) === true) {
        MyCustomHero.class = Number(readlineSync.keyInSelect(getClasses, `${'\t'.repeat(9)}\x1b[36mCHARACTER'S CLASS ➳ \x1b[0m`));
      } else test1 = false;
    }
    test1 = true;

    myCreatedHero = MyCustomHero; // sending all the user's datas to myCreatedHero
    // exemple: (rouge)

    console.log(`\n\n\x1b[34m${'\t'.repeat(7)} ------ YOUR CHARACTER ${myCreatedHero.name} IS NOW CREATED ! ------ \x1b[0m
    \n${'\t'.repeat(8)}\x1b[31mstrenght 🗡️ :\x1b[0m${'\t'.repeat(3)}${myCreatedHero.str} 
    \n${'\t'.repeat(8)}\x1b[34mhp 🌱 :\x1b[0m${'\t'.repeat(4)}${myCreatedHero.hp}
    \n${'\t'.repeat(8)}\x1b[33mdef 🛡️ :\x1b[0m${'\t'.repeat(4)}${myCreatedHero.def}
    \n${'\t'.repeat(8)}\x1b[34mspeed 🥷🏼 :\x1b[0m${'\t'.repeat(3)}${myCreatedHero.spd}
    \n${'\t'.repeat(8)}\x1b[32mluck 🍀 :\x1b[0m${'\t'.repeat(3)}${myCreatedHero.luck}
    \n${'\t'.repeat(8)}\x1b[31mintelligence💡 :\x1b[0m${'\t'.repeat(2)}${myCreatedHero.int}
    \n${'\t'.repeat(8)}\x1b[33mrarity 💎 :\x1b[0m${'\t'.repeat(3)}${myCreatedHero.rarity}
    \n${'\t'.repeat(8)}\x1b[35mRace 🧬 :\x1b[0m${'\t'.repeat(3)}${getRaces[myCreatedHero.race]} 
    \n${'\t'.repeat(8)}\x1b[36mClass 🎭 :\x1b[0m${'\t'.repeat(3)}${getClasses[myCreatedHero.class]}\n`);

    const userValidation: string = readlineSync.question(`${'\t'.repeat(7)}\x1b[33m****** START THE GAME WITH THE CHARACTER ****** [y/n]=>\x1b[0m`); // asking the user validation to start the game
    Messages.breakLine();
    if (userValidation === 'y') isTrue = false; // if yes : we break through the loop
  }
  return myCreatedHero; // returning the final created hero
}
