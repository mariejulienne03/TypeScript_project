/*
 ETNA PROJECT, 2023
 hyrule_castle
 File description:
         Create RPG game
*/
import * as Monsterss from './characters/enemies.json'; // Import Monsters array
import * as Heros from './characters/Hero.json'; // Import Heros array
import * as Boss from './characters/boss.json'; // Import Boss array
import GameStart from './mods/basicGameCustom';
import launchGame from './baseGame';
import shuffleArray from './shuffleArray'; // Import shuffle array
import Characters from './Interfaces/InterfaceCharacters';

const monsters: Characters[] = shuffleArray(Monsterss); // Storage array Monsters
const Bosses: Characters[] = shuffleArray(Boss); // Storage array Monsters
const heroes: Characters[] = shuffleArray(Heros); // Storage array Heroes
const nbrFloor: number[] = [10];

if (GameStart(monsters, Bosses, nbrFloor)) {
  launchGame(monsters, heroes, Bosses, nbrFloor); // Run the function
}
