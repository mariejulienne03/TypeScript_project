import Characters from './Interfaces/InterfaceCharacters';

export default function shuffleArray(
  arrayCharacter: Characters[] | Characters[],
): Characters[] | Characters[] {
  let i = 0;
  let result = Math.floor(Math.random() * (100 - 1) + 1); // getting a random number (1 - 100)
  let resultatFinal = 0;
  let tabEvil = [];
  const NewTab: Characters[] = [];

  while (NewTab.length < 100) {
    while (i < arrayCharacter.length) {
      if (result === 1) { // rarety 5
        if (arrayCharacter[i].rarity === 5) tabEvil.push({ ...arrayCharacter[i] });
      } else if (result > 1 && result <= 4) { // rarety of 4
        if (arrayCharacter[i].rarity === 4) tabEvil.push({ ...arrayCharacter[i] });
      } else if (result >= 5 && result < 20) { // rarety of 3
        if (arrayCharacter[i].rarity === 3) tabEvil.push({ ...arrayCharacter[i] });
      } else if (result >= 20 && result < 50) { // rarety of 2
        if (arrayCharacter[i].rarity === 2) tabEvil.push({ ...arrayCharacter[i] });
      } else if (result >= 50 && result <= 100) { // rarety of 1
        if (arrayCharacter[i].rarity === 1) tabEvil.push({ ...arrayCharacter[i] });
      }
      i += 1;
    }
    resultatFinal = Math.floor(Math.random() * (tabEvil.length)); // getting a random index of array

    NewTab.push(tabEvil[resultatFinal]); // pushing the random index into a new array

    tabEvil = [];
    result = Math.floor(Math.random() * (100 - 1) + 1);
    i = 0;
  }
  return NewTab;
}
