import Messages from './getAllMessages'; // Import display floor
import Characters from './Interfaces/InterfaceCharacters';
import { heroAttack, heroHeal } from './heroSpell'; // Import Hero attacks
import MonsterAttacks from './ennemyAttacks'; // Import Monster attack
import getEscape from './mods/moreOptionsHero';
import { getRandomXp, levelUp } from './mods/levelUp';
import chooseCharacter from './mods/chooseCharacter';
import Level from './Interfaces/IntefaceLevel';

const rl = require('readline-sync'); // Import readline-sync

const coins: number[] = [12];
const heroLevel: Level = {
  xp: 0,
  level: 1,
  containerXp: 50,
};

export default function launchGame(
  arrayMonsters: Characters[],
  ArrayHero: Characters[],
  arrayBoss: Characters[],
  nbrFight: number[],
): boolean {
  chooseCharacter(ArrayHero);
  const Hero: Characters = ArrayHero[0]; // Storage obj Hero
  let Monster: Characters = arrayMonsters[0]; // Storage obj Monster
  let hpMonsterMax: number = Monster.hp; // Storage life max Monster
  const hpHeroMax: number[] = [Hero.hp]; // Storage life max Hero
  let floor: number = 1; // Initializing deck

  if (Hero.name.toLowerCase() === 'malek') {
    Messages.getMalek(Hero.name, nbrFight[0]);
    return false;
  }
  Messages.getIntro(Hero.name, arrayBoss[0].name);
  Messages.getFloor(floor); // Call deck function
  Messages.getMonsterCome(Monster.name);

  while (arrayMonsters.length > 1 || arrayBoss[0].hp > 0) { // Checking if there are still monsters
    if (Monster.hp === 0) { // if life mosnter is down
      coins[0] += 1;
      heroLevel.xp += getRandomXp();
      if (heroLevel.xp >= heroLevel.containerXp) levelUp(heroLevel, Hero, hpHeroMax);

      Messages.getCoins(coins[0]);
      rl.keyInPause(Messages.getPause(Hero.name, Monster.name, floor));
      arrayMonsters.shift(); // remove the first index of array
      floor += 1; // Incrementing the position of the deck

      Monster = (floor % 10) ? arrayMonsters[0] : arrayBoss[0]; // initializing the next monster
      hpMonsterMax = Monster.hp; // initializing life of the monster
      Messages.getFloor(floor);
      Messages.getMonsterCome(Monster.name);
    }

    const choicePlayer: string = rl.question( // Collecting user's choice in shell
      Messages.getInterface(
        Monster,
        Hero,
        hpMonsterMax,
        hpHeroMax[0],
        heroLevel,
      ), // Include All characters interfaces
      (res: '1' | '2' | '3' | '4') => (res),
    );

    if (choicePlayer === '1') heroAttack(Hero.str, Monster); // Call hero attack function if is true
    else if (choicePlayer === '2') heroHeal(Hero, hpHeroMax[0]); // Call hero heal function if is true
    else if (choicePlayer === '4') getEscape(Monster, Hero); // Call hero heal function if is true
    if (Monster.hp > 0) { // Call monster attack if he's still alive
      if (choicePlayer === '3') MonsterAttacks(Hero, Monster, true);
      else MonsterAttacks(Hero, Monster, false);
    }
    if (arrayBoss[0].hp <= 0) {
      nbrFight[0] -= 10;
      if (nbrFight[0] <= 0) {
        Messages.getBossDefeat(Monster.name, Hero.name);
        Messages.getTheEnd(Hero.name);
        break;
      }
      if (choicePlayer !== '4') Messages.getBossDefeat(Monster.name, Hero.name);
      arrayBoss.shift();
    }
    if (Hero.hp <= 0) { // if hero dies break off the loop
      Messages.getDieHero();
      break;
    }
  }
  return true;
}
